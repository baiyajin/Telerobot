<?php
// +----------------------------------------------------------------------
// | RuiKeCMS [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016 http://www.ruikesoft.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: Wayne <wayne@ruikesoft.com> <http://www.ruikesoft.com>
// +----------------------------------------------------------------------
use think\Route;
// ע��·�ɵ�indexģ���News��������read����
//Route::rule('new/:token','wap/wxactivity/main');
//Route::rule('achao','user/index/login');
//Route::alias('achao','user/index/login');
//Route::bind('index');
//Route::miss('index');
//Route::domain('api','api');
//Route::domain('wap','wap');
//Route::domain('manage','user');
