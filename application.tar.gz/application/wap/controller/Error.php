<?php
namespace app\wap\controller;
use app\common\controller\Wap;
use think\Request;

class Error{
	public function index()
	{
		echo '';exit;
		
	}
	
}













